import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:uuid/uuid.dart';
import '../models/chat_model.dart';
import '../config/constants.dart';
import '../utils/content_filter.dart';

/// Chat service — manages chats and messages with content filtering
class ChatService {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  final Uuid _uuid = const Uuid();

  CollectionReference get _chatsRef =>
      _firestore.collection(AppConstants.chatsCollection);

  /// Stream of active chats for a user
  Stream<List<ChatModel>> getChatsStream(String userId) {
    return _chatsRef
        .where('participants', arrayContains: userId)
        .where('status', isEqualTo: 'active')
        .orderBy('last_message_at', descending: true)
        .snapshots()
        .map((snapshot) =>
            snapshot.docs.map((doc) => ChatModel.fromFirestore(doc)).toList());
  }

  /// Get a single chat
  Future<ChatModel?> getChat(String chatId) async {
    final doc = await _chatsRef.doc(chatId).get();
    if (!doc.exists) return null;
    return ChatModel.fromFirestore(doc);
  }

  /// Stream a single chat for real-time updates
  Stream<ChatModel?> getChatStream(String chatId) {
    return _chatsRef.doc(chatId).snapshots().map((doc) {
      if (!doc.exists) return null;
      return ChatModel.fromFirestore(doc);
    });
  }

  /// Stream messages for a chat
  Stream<List<MessageModel>> getMessagesStream(String chatId) {
    return _chatsRef
        .doc(chatId)
        .collection(AppConstants.messagesSubcollection)
        .orderBy('created_at', descending: false)
        .snapshots()
        .map((snapshot) =>
            snapshot.docs.map((doc) => MessageModel.fromFirestore(doc)).toList());
  }

  /// Send a message with content filtering
  Future<MessageModel?> sendMessage({
    required String chatId,
    required String senderId,
    required String text,
  }) async {
    // Content filtering
    final filterResult = ContentFilter.filterMessage(text);
    if (!filterResult.isAllowed) {
      throw ContentFilterException(filterResult.reason ?? 'Message blocked');
    }

    final messageId = _uuid.v4();
    final now = DateTime.now();
    final message = MessageModel(
      messageId: messageId,
      senderId: senderId,
      text: filterResult.filteredText,
      createdAt: now,
    );

    final batch = _firestore.batch();

    // Add message
    batch.set(
      _chatsRef
          .doc(chatId)
          .collection(AppConstants.messagesSubcollection)
          .doc(messageId),
      message.toMap(),
    );

    // Update chat with last message info and reset expiry
    batch.update(_chatsRef.doc(chatId), {
      'last_message': filterResult.filteredText,
      'last_message_at': Timestamp.fromDate(now),
      'expires_at': Timestamp.fromDate(
        now.add(const Duration(minutes: AppConstants.chatInactivityExpiryMinutes)),
      ),
    });

    await batch.commit();
    return message;
  }

  /// End a chat (used when blocking)
  Future<void> endChat(String chatId) async {
    await _chatsRef.doc(chatId).update({
      'status': 'blocked',
    });
  }
}

/// Exception thrown when content filter blocks a message
class ContentFilterException implements Exception {
  final String message;
  const ContentFilterException(this.message);

  @override
  String toString() => message;
}
