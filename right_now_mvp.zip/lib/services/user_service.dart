import 'package:cloud_firestore/cloud_firestore.dart';
import '../models/user_model.dart';
import '../config/constants.dart';

/// User profile CRUD operations
class UserService {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  CollectionReference get _usersRef =>
      _firestore.collection(AppConstants.usersCollection);

  /// Create a new user profile
  Future<void> createUser(UserModel user) async {
    await _usersRef.doc(user.uid).set(user.toMap());
  }

  /// Get user by UID
  Future<UserModel?> getUser(String uid) async {
    final doc = await _usersRef.doc(uid).get();
    if (!doc.exists) return null;
    return UserModel.fromFirestore(doc);
  }

  /// Get user stream for real-time updates
  Stream<UserModel?> getUserStream(String uid) {
    return _usersRef.doc(uid).snapshots().map((doc) {
      if (!doc.exists) return null;
      return UserModel.fromFirestore(doc);
    });
  }

  /// Update user profile fields
  Future<void> updateUser(String uid, Map<String, dynamic> updates) async {
    updates['last_active'] = Timestamp.fromDate(DateTime.now());
    await _usersRef.doc(uid).update(updates);
  }

  /// Update content mode (safe/open) with validation
  Future<void> updateContentMode(String uid, ContentMode mode) async {
    await _usersRef.doc(uid).update({
      'content_mode': mode.value,
      'last_active': Timestamp.fromDate(DateTime.now()),
    });
  }

  /// Mark user as verified after selfie verification
  Future<void> verifyUser(String uid) async {
    await _usersRef.doc(uid).update({
      'verified': true,
      'last_active': Timestamp.fromDate(DateTime.now()),
    });
  }

  /// Add photo URL to user profile (max 3)
  Future<void> addPhotoUrl(String uid, String photoUrl) async {
    final user = await getUser(uid);
    if (user == null) return;
    if (user.photoUrls.length >= AppConstants.maxPhotos) return;

    await _usersRef.doc(uid).update({
      'photo_urls': FieldValue.arrayUnion([photoUrl]),
      'last_active': Timestamp.fromDate(DateTime.now()),
    });
  }

  /// Remove photo URL from user profile
  Future<void> removePhotoUrl(String uid, String photoUrl) async {
    await _usersRef.doc(uid).update({
      'photo_urls': FieldValue.arrayRemove([photoUrl]),
      'last_active': Timestamp.fromDate(DateTime.now()),
    });
  }

  /// Update last active timestamp
  Future<void> updateLastActive(String uid) async {
    await _usersRef.doc(uid).update({
      'last_active': Timestamp.fromDate(DateTime.now()),
    });
  }
}
